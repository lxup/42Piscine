/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lquehec <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/04 12:59:41 by lquehec           #+#    #+#             */
/*   Updated: 2023/08/04 13:05:45 by lquehec          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	if(!*str)
		return (1);
	while(str[i] != '\0')
	{
		if(str[i] >= 'a' && str[i] <= 'z')
			i++;
		else
			return (0);
	}
	return (1);
}

int	main()
{
	char	*text;

	text = "";
	printf("OUTPUT: %d", ft_str_is_lowercase(text));
	return (0);
}
