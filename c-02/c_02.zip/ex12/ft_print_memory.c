#include <unistd.h>

void    *ft_print_memory(void *addr, unsigned int size)
{
    return (addr);
}

int main()
{
    char    text[] = "SALUT";
    char    text2[] = "OUAAAI";

    ft_print_memory();
}